# Ernawati-Mashita

## Portofolio Ernawati Mashita

Halo! Saya **Ernawati Mashita**, siswa **SMKN 1 Semparuk** dari jurusan **Rekayasa Perangkat Lunak (RPL)**.

### Tentang
Repository ini berisi portofolio dan proyek pembelajaran saya di bidang teknologi informasi dan pengembangan website.

### Keahlian
- HTML
- CSS
- JavaScript
- C++
- Dasar pengembangan website

### Proyek
- Website Portofolio
- Florea - Konsep Website Buket Bunga

### Cara menjalankan
Buka file `index.html` menggunakan browser.

---
© 2026 Ernawati Mashita | SMKN 1 Semparuk

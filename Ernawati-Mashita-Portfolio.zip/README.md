# Portofolio Ernawati Mashita

Website portofolio pribadi Ernawati Mashita, siswi SMKN 1 Semparuk jurusan Rekayasa Perangkat Lunak (RPL).

## Isi Website
- Beranda
- Tentang Saya
- Kesukaan & Minat
- Pendidikan
- Cita-Cita
- Kontak

## Teknologi
- HTML
- CSS

Buka `index.html` untuk menjalankan website secara lokal.
